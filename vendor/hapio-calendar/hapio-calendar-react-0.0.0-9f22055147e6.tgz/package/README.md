# @hapio/calendar-react

React 19 bindings of Hapio Calendar, a free calendar and scheduler for React and shadcn/ui:
headless hooks that render no DOM and return prop-getters with the roles, ARIA, ids, keyboard
handling and geometry of each part. The styled calendar is the `hapio-calendar` block of the
`@hapio` shadcn registry, built on these hooks, which you copy into your app and own.

## Install

The usual way is the registry block, which installs this package with it:

```bash
npx shadcn@latest add @hapio/hapio-calendar
```

For your own markup:

```bash
npm install @hapio/calendar-react temporal-polyfill
```

Load `temporal-polyfill/global` once per app where the runtime has no native `Temporal`. React
and React DOM 19.2 or later; ESM only.

## Example

A list of the week's events in your own markup:

```tsx
'use client'

import { CalendarProvider, useCalendar, useList } from '@hapio/calendar-react'

interface Booking {
  readonly id: string
  readonly title: string
  readonly start: string
  readonly end: string
}

export function Agenda({ bookings }: { readonly bookings: readonly Booking[] }) {
  const calendar = useCalendar({
    events: bookings,
    timeZone: 'Europe/Stockholm',
    defaultView: 'list',
  })
  return (
    <CalendarProvider value={calendar}>
      <div {...calendar.getRootProps()}>
        <Days />
      </div>
    </CalendarProvider>
  )
}

function Days() {
  const list = useList()
  if (list.isEmpty) return <div {...list.getEmptyProps()}>{list.emptyText}</div>
  return (
    <ul {...list.getListProps()}>
      {list.days.map((day) => (
        <li key={day.key} {...list.getDayProps(day)}>
          <h3 {...list.getDayHeadingProps(day)}>{day.heading}</h3>
          <ul {...list.getDayListProps(day)}>
            {day.segments.map((segment) => (
              <li key={segment.key} {...list.getItemProps(segment)}>
                {segment.event.title}
              </li>
            ))}
          </ul>
        </li>
      ))}
    </ul>
  )
}
```

`@hapio/calendar-react/interaction` adds selection, editing and drag-in; `./testing` the
contract checker and `runConformance` for markup of your own.

## Documentation

https://calendar.hapio.io/docs

## License

MIT. See `LICENSE`.

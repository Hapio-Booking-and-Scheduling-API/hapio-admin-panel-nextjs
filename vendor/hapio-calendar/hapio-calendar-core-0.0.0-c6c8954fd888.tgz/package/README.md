# @hapio/calendar-core

The framework-free engine of Hapio Calendar, a free calendar and scheduler for React and
shadcn/ui: dates and time zones, views and their visible ranges, events, sources, rules,
layout, formats, strings and the calendar store. No DOM and no framework, so it is safe to import
in React Server Components and on the server.

Most apps never install it directly: `@hapio/calendar-react` re-exports all of it, and the
`hapio-calendar` registry block installs that. Use this package in server code, in another
binding, or where you only need its pure functions.

## Install

```bash
npm install @hapio/calendar-core temporal-polyfill
```

The dates are [Temporal](https://tc39.es/proposal-temporal/docs/) objects: load
`temporal-polyfill/global` once per app where the runtime has no native `Temporal`. ESM only;
Node 22.12 or later.

## Example

The range a week view shows, computed on the server (no clock read: give the date):

```ts
import { defaultViews, getVisibleRange } from '@hapio/calendar-core'

const range = getVisibleRange(defaultViews.week, {
  date: '2026-10-21',
  timeZone: 'Europe/Stockholm',
})
// range.startIso: '2026-10-19T00:00:00+02:00', range.endIso: '2026-10-26T00:00:00+01:00'
```

Entry points: `.` (the engine), `./interaction` (the selection, editing and external-drop engines),
`./layout` (the layout algorithms), `./dom` (the pointer engine), `./series` (the store side of
recurring series), `./locales/en` and `./locales/sv` (string packs) and `./testing`.

## Documentation

https://calendar.hapio.io/docs

## License

MIT. Parts of the locale week data are derived from Unicode CLDR under the Unicode License v3;
see `LICENSE`.
